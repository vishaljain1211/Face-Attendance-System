# Face-recognition-attendance-system
We made a PYTHON based face recognition attendance system for school and Universities which works with following steps :-  

1. Teacher/Professor enters the class with an app (Created by us) installed in their smartphone with internet connectivity.  
2. Teacher/Professor click the picture of whole class in one go and upload it through our app installed on their smartphone.  
3. Based on the class database, we match each face in the photo upload by the teacher / professor and create a present and      absent list of the students. 
4. The attendance will be updated in the database as well as teacher / professor will receive a mail that attendance has been updated and list of present and absent student will be also attached for cross verification.


The main process behind this project is that the photo uploaded by the teacher will be checked for faces first and then after getting all the location of all the faces in that photo , we match it with face encodings of the faces of the students in tha database.
